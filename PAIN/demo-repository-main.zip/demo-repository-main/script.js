const steps = [...document.querySelectorAll('#steps .dot')];
const screens = {
intro: document.getElementById('screen-intro'),
passage: document.getElementById('screen-passage'),
question: document.getElementById('screen-question'),
results: document.getElementById('screen-results'),
};
const order = ['intro', 'passage', 'question', 'results'];

function goTo(name) {
stopSpeaking();
order.forEach((n, i) => {
    screens[n].classList.toggle('visible', n === name);
    const idx = order.indexOf(name);
    steps[i].classList.toggle('done', i < idx);
    steps[i].classList.toggle('active', i === idx);
});
if (name === 'passage') playPrompt(document.getElementById('passage-text').textContent, 'btn-mic-passage');
if (name === 'question') playPrompt(document.getElementById('q-text').textContent, 'btn-mic-question');
}

// --- Speech recognition setup ---
const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
if (SpeechRecognitionAPI) {
recognition = new SpeechRecognitionAPI();
recognition.continuous = true;
recognition.interimResults = true;
recognition.lang = 'en-US';
}

// --- AI voice playback (Play/Stop toggle) ---
let speakingBtn = null;

function stopSpeaking() {
speechSynthesis.cancel();
if (speakingBtn) {
    speakingBtn.textContent = '🔊 Play';
    const micBtn = document.getElementById(speakingBtn.dataset.micBtn);
    if (micBtn) micBtn.disabled = false;
    speakingBtn = null;
}
}

function togglePlay(btn, text) {
if (speakingBtn === btn) { stopSpeaking(); return; }
stopSpeaking();
if (!('speechSynthesis' in window)) return;
const micBtn = document.getElementById(btn.dataset.micBtn);
if (micBtn) micBtn.disabled = true;
speakingBtn = btn;
btn.textContent = '⏹ Stop';
const utterance = new SpeechSynthesisUtterance(text);
utterance.lang = 'en-US';
utterance.rate = 0.95;
utterance.onend = () => { if (speakingBtn === btn) stopSpeaking(); };
utterance.onerror = () => { if (speakingBtn === btn) stopSpeaking(); };
speechSynthesis.speak(utterance);
}

function playPrompt(text, micBtnId) {
const btn = micBtnId === 'btn-mic-passage'
    ? document.getElementById('btn-replay-passage')
    : document.getElementById('btn-replay-question');
btn.dataset.micBtn = micBtnId;
togglePlay(btn, text);
}

document.getElementById('btn-start').addEventListener('click', () => goTo('passage'));
document.getElementById('btn-replay-passage').dataset.micBtn = 'btn-mic-passage';
document.getElementById('btn-replay-passage').addEventListener('click', () => {
togglePlay(document.getElementById('btn-replay-passage'), document.getElementById('passage-text').textContent);
});
document.getElementById('btn-replay-question').dataset.micBtn = 'btn-mic-question';
document.getElementById('btn-replay-question').addEventListener('click', () => {
togglePlay(document.getElementById('btn-replay-question'), document.getElementById('q-text').textContent);
});

// --- Recording (shared recognition instance, one active recorder at a time) ---
let currentRecorder = null;

function wireRecorder({ micBtn, transcriptEl, nextBtn, onDone }) {
micBtn.addEventListener('click', () => {
    if (!recognition) {
    transcriptEl.textContent = 'Speech recognition is not supported in this browser.';
    return;
    }
    stopSpeaking(); // don't let the AI voice and mic overlap

    if (currentRecorder && currentRecorder.micBtn === micBtn) {
    recognition.stop(); // finalization happens in recognition.onend below
    } else {
    if (currentRecorder) recognition.stop();
    transcriptEl.textContent = '';
    nextBtn.disabled = true;
    micBtn.textContent = '⏹️ Stop';
    micBtn.classList.add('recording');
    currentRecorder = { transcriptEl, nextBtn, micBtn, finalTranscript: '', startTime: performance.now(), onDone };
    try { recognition.start(); } catch (e) {}
    }
});
}

if (recognition) {
recognition.addEventListener('result', (event) => {
    if (!currentRecorder) return;
    let interim = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
    const text = event.results[i][0].transcript;
    if (event.results[i].isFinal) currentRecorder.finalTranscript += text + ' ';
    else interim += text;
    }
    currentRecorder.transcriptEl.textContent = (currentRecorder.finalTranscript + interim).trim();
});

recognition.addEventListener('end', () => {
    if (!currentRecorder) return;
    const r = currentRecorder;
    currentRecorder = null;
    r.micBtn.textContent = '🎙️ Record';
    r.micBtn.classList.remove('recording');
    const duration = Math.max((performance.now() - r.startTime) / 1000, 1);
    const finalText = r.transcriptEl.textContent.trim();
    r.nextBtn.disabled = finalText.length === 0;
    r.onDone(finalText, duration);
});
}

let passageResult = { transcript: '', duration: 1 };
let questionResult = { transcript: '', duration: 1 };

wireRecorder({
micBtn: document.getElementById('btn-mic-passage'),
transcriptEl: document.getElementById('transcript-passage'),
nextBtn: document.getElementById('btn-next-passage'),
onDone: (t, d) => { passageResult = { transcript: t, duration: d }; }
});

wireRecorder({
micBtn: document.getElementById('btn-mic-question'),
transcriptEl: document.getElementById('transcript-question'),
nextBtn: document.getElementById('btn-next-question'),
onDone: (t, d) => { questionResult = { transcript: t, duration: d }; }
});

document.getElementById('btn-next-passage').addEventListener('click', () => goTo('question'));
document.getElementById('btn-next-question').addEventListener('click', () => {
showResults();
goTo('results');
});

// --- Scoring ---
function accuracyScore(expectedText, transcript) {
const expectedWords = expectedText.toLowerCase().replace(/[.,]/g, '').split(/\s+/).filter(Boolean);
const saidWords = new Set(transcript.toLowerCase().replace(/[.,]/g, '').split(/\s+/));
const matched = expectedWords.filter(w => saidWords.has(w)).length;
return Math.round((matched / expectedWords.length) * 100);
}
function fluencyScore(transcript, durationSec) {
const words = transcript.trim().split(/\s+/).filter(Boolean);
if (words.length === 0) return 0;
const wpm = words.length / (durationSec / 60);
const fillerCount = (transcript.match(/\b(um|uh|like|you know|kind of|sort of)\b/gi) || []).length;
const fillerRatio = fillerCount / words.length;
const speedScore = (wpm >= 70 && wpm <= 150) ? 100 : Math.max(0, 100 - Math.abs(wpm - 110));
const fillerScore = Math.max(0, 100 - fillerRatio * 250);
return Math.round(speedScore * 0.6 + fillerScore * 0.4);
}
function rangeScore(transcript) {
const words = transcript.toLowerCase().split(/\s+/).filter(Boolean);
if (words.length === 0) return 0;
const uniqueWords = new Set(words).size;
return Math.round(Math.min((uniqueWords / words.length) * 150, 100));
}
function coherenceScore(transcript) {
const words = transcript.split(/\s+/).filter(Boolean);
if (words.length === 0) return 0;
const connectors = (transcript.match(/\b(because|so|then|but|also|after|before|therefore|however)\b/gi) || []).length;
const expected = Math.max(words.length / 15, 1);
return Math.round(Math.min((connectors / expected) * 100, 100));
}

function cefrLevel(score) {
if (score < 25) return 'A1';
if (score < 45) return 'A2';
if (score < 65) return 'B1';
if (score < 80) return 'B2';
if (score < 93) return 'C1';
return 'C2';
}

function buildFeedback(scores) {
const tips = [];
if (scores.accuracy < 60) tips.push('Read a little slower and sound out each word — accuracy improves before speed does.');
if (scores.fluency < 60) tips.push('Practice speaking in short phrases without long pauses; try recording yourself daily for a minute.');
if (scores.range < 60) tips.push('Try using synonyms instead of repeating the same words (e.g. "happy" → "glad", "great").');
if (scores.coherence < 60) tips.push('Link your ideas with words like "because", "so", and "after" to help your answer flow.');
if (tips.length === 0) tips.push('Strong, well-rounded performance — keep practicing longer, more detailed answers.');
return tips;
}

function showResults() {
const passageText = document.getElementById('passage-text').textContent;
const accuracy = accuracyScore(passageText, passageResult.transcript);
const fluency = fluencyScore(questionResult.transcript, questionResult.duration);
const range = rangeScore(questionResult.transcript);
const coherence = coherenceScore(questionResult.transcript);
const overall = Math.round(accuracy * 0.25 + fluency * 0.3 + range * 0.2 + coherence * 0.25);

document.getElementById('overall-num').textContent = overall;
document.getElementById('cefr-badge').textContent = 'CEFR level: ' + cefrLevel(overall);

const criteria = [
    { name: 'Reading Accuracy', val: accuracy, note: 'How closely your reading matched the original passage.' },
    { name: 'Fluency', val: fluency, note: 'Speaking pace and how few hesitations you had.' },
    { name: 'Vocabulary Range', val: range, note: 'Variety of different words used.' },
    { name: 'Coherence', val: coherence, note: 'Use of connecting words to link your ideas.' },
];

const list = document.getElementById('criteria-list');
list.innerHTML = '';
criteria.forEach(c => {
    const div = document.createElement('div');
    div.className = 'criterion';
    div.innerHTML = `
    <div class="top"><span class="name">${c.name}</span><span class="val">${c.val}/100</span></div>
    <div class="bar"><span style="width:${c.val}%"></span></div>
    <div class="note">${c.note}</div>
    `;
    list.appendChild(div);
});

const tips = buildFeedback({ accuracy, fluency, range, coherence });
const adaptiveNote = overall >= 70
    ? 'Since you scored well, your next test will be adaptive and include more challenging passages and questions.'
    : overall < 40
    ? 'Your next test will be adaptive and adjust to an easier level to build your confidence.'
    : 'Your next test will be adaptive, adjusting slightly based on this result.';

document.getElementById('feedback-box').innerHTML = `
    <h3>Tips to improve</h3>
    <ul>${tips.map(t => `<li>${t}</li>`).join('')}</ul>
    <div class="adaptive-note">${adaptiveNote}</div>
`;
}

goTo('intro');
